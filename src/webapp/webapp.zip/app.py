"""
Azure Pricing History - Web Visualization App
Simple Flask application to visualize pricing data from Azure SQL Database
"""

import os
import logging
import struct
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request
from azure.identity import DefaultAzureCredential
import pyodbc

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Database configuration from environment variables
SQL_SERVER = os.environ.get('SQL_SERVER_FQDN', 'sql-pricing-dev-gwc.database.windows.net')
SQL_DATABASE = os.environ.get('SQL_DATABASE_NAME', 'sqldb-pricing-dev')
SQL_DRIVER = '{ODBC Driver 18 for SQL Server}'


def get_db_connection():
    """Create database connection using Managed Identity"""
    try:
        # Get access token for Azure SQL Database
        credential = DefaultAzureCredential()
        token = credential.get_token("https://database.windows.net/.default")
        
        # Encode token as UTF-16-LE bytes and pack into struct
        token_bytes = token.token.encode("UTF-16-LE")
        token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)
        
        # Build connection string (no username/password)
        connection_string = (
            f'Driver={SQL_DRIVER};'
            f'Server=tcp:{SQL_SERVER},1433;'
            f'Database={SQL_DATABASE};'
            f'Encrypt=yes;'
            f'TrustServerCertificate=no;'
            f'Connection Timeout=30;'
        )
        
        logger.info(f"Connecting to SQL Server: {SQL_SERVER}")
        
        # Connect with access token (SQL_COPT_SS_ACCESS_TOKEN = 1256)
        conn = pyodbc.connect(connection_string, attrs_before={1256: token_struct})
        
        logger.info("Successfully connected to database using Managed Identity")
        return conn
        
    except Exception as e:
        logger.error(f"Failed to connect to database: {e}")
        raise

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html')

@app.route('/api/summary')
def get_summary():
    """Get summary statistics"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get overall statistics
        cursor.execute("""
            SELECT 
                COUNT(DISTINCT meterId) as totalMeters,
                COUNT(DISTINCT serviceName) as totalServices,
                COUNT(DISTINCT armRegionName) as totalRegions,
                COUNT(DISTINCT currencyCode) as totalCurrencies,
                MAX(lastSeenUtc) as lastUpdate
            FROM dbo.AzureRetailPrices
        """)
        
        row = cursor.fetchone()
        summary = {
            'totalMeters': row.totalMeters,
            'totalServices': row.totalServices,
            'totalRegions': row.totalRegions,
            'totalCurrencies': row.totalCurrencies,
            'lastUpdate': row.lastUpdate.isoformat() if row.lastUpdate else None
        }
        
        # Get snapshot statistics
        cursor.execute("""
            SELECT 
                COUNT(*) as totalSnapshots,
                SUM(CASE WHEN status = 'SUCCEEDED' THEN 1 ELSE 0 END) as successfulSnapshots,
                MAX(startedUtc) as lastSnapshotDate
            FROM dbo.PriceSnapshotRuns
        """)
        
        row = cursor.fetchone()
        summary['totalSnapshots'] = row.totalSnapshots
        summary['successfulSnapshots'] = row.successfulSnapshots
        summary['lastSnapshotDate'] = row.lastSnapshotDate.isoformat() if row.lastSnapshotDate else None
        
        conn.close()
        return jsonify(summary)
    except Exception as e:
        logger.error(f"Error getting summary: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/services')
def get_services():
    """Get top services by meter count"""
    try:
        limit = request.args.get('limit', 15, type=int)
        currency = request.args.get('currency', 'USD')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT TOP (?) 
                serviceName,
                COUNT(DISTINCT meterId) as meterCount,
                AVG(retailPrice) as avgPrice,
                MIN(retailPrice) as minPrice,
                MAX(retailPrice) as maxPrice
            FROM dbo.v_CurrentRetailPrices
            WHERE currencyCode = ?
                AND retailPrice > 0
                AND serviceName IS NOT NULL
            GROUP BY serviceName
            ORDER BY meterCount DESC
        """, limit, currency)
        
        services = []
        for row in cursor.fetchall():
            services.append({
                'name': row.serviceName,
                'meterCount': row.meterCount,
                'avgPrice': float(row.avgPrice) if row.avgPrice else 0,
                'minPrice': float(row.minPrice) if row.minPrice else 0,
                'maxPrice': float(row.maxPrice) if row.maxPrice else 0
            })
        
        conn.close()
        return jsonify(services)
    except Exception as e:
        logger.error(f"Error getting services: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/regions')
def get_regions():
    """Get pricing by region"""
    try:
        currency = request.args.get('currency', 'USD')
        service = request.args.get('service', None)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = """
            SELECT 
                armRegionName,
                COUNT(DISTINCT meterId) as meterCount,
                AVG(retailPrice) as avgPrice
            FROM dbo.v_CurrentRetailPrices
            WHERE currencyCode = ?
                AND retailPrice > 0
                AND armRegionName IS NOT NULL
        """
        params = [currency]
        
        if service:
            query += " AND serviceName = ?"
            params.append(service)
        
        query += """
            GROUP BY armRegionName
            ORDER BY meterCount DESC
        """
        
        cursor.execute(query, *params)
        
        regions = []
        for row in cursor.fetchall():
            regions.append({
                'region': row.armRegionName,
                'meterCount': row.meterCount,
                'avgPrice': float(row.avgPrice) if row.avgPrice else 0
            })
        
        conn.close()
        return jsonify(regions)
    except Exception as e:
        logger.error(f"Error getting regions: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/price-trends')
def get_price_trends():
    """Get price trends over time for a specific meter"""
    try:
        meter_id = request.args.get('meterId', None)
        service = request.args.get('service', 'Virtual Machines')
        currency = request.args.get('currency', 'USD')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if meter_id:
            # Specific meter trend
            cursor.execute("""
                SELECT 
                    effectiveStartDate,
                    retailPrice,
                    productName,
                    skuName,
                    meterName
                FROM dbo.v_PriceHistory
                WHERE meterId = ?
                    AND currencyCode = ?
                ORDER BY effectiveStartDate DESC
            """, meter_id, currency)
        else:
            # Average service trend
            cursor.execute("""
                SELECT 
                    effectiveStartDate,
                    AVG(retailPrice) as retailPrice,
                    serviceName as productName,
                    COUNT(DISTINCT meterId) as meterCount
                FROM dbo.AzureRetailPrices
                WHERE serviceName = ?
                    AND currencyCode = ?
                    AND retailPrice > 0
                GROUP BY effectiveStartDate, serviceName
                ORDER BY effectiveStartDate DESC
            """, service, currency)
        
        trends = []
        for row in cursor.fetchall():
            trends.append({
                'date': row.effectiveStartDate.isoformat(),
                'price': float(row.retailPrice) if row.retailPrice else 0,
                'productName': row.productName if hasattr(row, 'productName') else service
            })
        
        conn.close()
        return jsonify(trends)
    except Exception as e:
        logger.error(f"Error getting price trends: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/snapshots')
def get_snapshots():
    """Get snapshot run history"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT TOP 20
                snapshotId,
                currencyCode,
                startedUtc,
                finishedUtc,
                status,
                itemCount,
                durationSeconds,
                itemsPerSecond
            FROM dbo.v_SnapshotRunSummary
            ORDER BY startedUtc DESC
        """)
        
        snapshots = []
        for row in cursor.fetchall():
            snapshots.append({
                'snapshotId': row.snapshotId,
                'currency': row.currencyCode,
                'startedUtc': row.startedUtc.isoformat(),
                'finishedUtc': row.finishedUtc.isoformat() if row.finishedUtc else None,
                'status': row.status,
                'itemCount': row.itemCount,
                'durationSeconds': row.durationSeconds,
                'itemsPerSecond': float(row.itemsPerSecond) if row.itemsPerSecond else 0
            })
        
        conn.close()
        return jsonify(snapshots)
    except Exception as e:
        logger.error(f"Error getting snapshots: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/search')
def search_prices():
    """Search pricing data"""
    try:
        query = request.args.get('q', '')
        currency = request.args.get('currency', 'USD')
        limit = request.args.get('limit', 50, type=int)
        
        if not query:
            return jsonify([])
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        search_term = f'%{query}%'
        cursor.execute("""
            SELECT TOP (?)
                meterId,
                productName,
                skuName,
                serviceName,
                meterName,
                armRegionName,
                retailPrice,
                unitOfMeasure,
                effectiveStartDate
            FROM dbo.v_CurrentRetailPrices
            WHERE currencyCode = ?
                AND (
                    productName LIKE ? 
                    OR skuName LIKE ?
                    OR serviceName LIKE ?
                    OR meterName LIKE ?
                )
            ORDER BY retailPrice DESC
        """, limit, currency, search_term, search_term, search_term, search_term)
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'meterId': row.meterId,
                'productName': row.productName,
                'skuName': row.skuName,
                'serviceName': row.serviceName,
                'meterName': row.meterName,
                'region': row.armRegionName,
                'price': float(row.retailPrice) if row.retailPrice else 0,
                'unit': row.unitOfMeasure,
                'effectiveDate': row.effectiveStartDate.isoformat()
            })
        
        conn.close()
        return jsonify(results)
    except Exception as e:
        logger.error(f"Error searching prices: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # For local development
    app.run(debug=True, host='0.0.0.0', port=5000)
